You have to install the Visual C++ 2005 Redistributable Package (x86) -> http://www.microsoft.com/downloads/details.aspx?familyid=32bc1bee-a3f9-4c13-9c99-220b62a191ee&displaylang=en
You also have to install OpenAL -> http://www.openal.org/downloads.html

Beware, Windstille will create a .Windstille directory in your user directoy and eventually put a config file in there. That's usual unixish behaviour, nothing to worry about.

Known defects of the Windows version:
Using F12 for screenshots is disabled (just use the print key instead)

Also have a look at the original README file.