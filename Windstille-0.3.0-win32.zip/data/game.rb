puts "XXX: game.rb is loading"

# EOF #
