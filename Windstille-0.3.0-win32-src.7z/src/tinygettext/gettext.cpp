#include "gettext.hpp"

TinyGetText::DictionaryManager* dictionaryManager = 0;

