#ifndef SCRIPTING_API
#define __custom
#define __suspend
#endif

#include "interface.hpp"
#include "spawn_object.hpp"
#include "game_objects.hpp"
