/*  $Id: random.hpp 1206 2006-01-09 08:52:53Z grumbel $
**   __      __ __             ___        __   __ __   __
**  /  \    /  \__| ____    __| _/_______/  |_|__|  | |  |   ____
**  \   \/\/   /  |/    \  / __ |/  ___/\   __\  |  | |  | _/ __ \
**   \        /|  |   |  \/ /_/ |\___ \  |  | |  |  |_|  |_\  ___/
**    \__/\  / |__|___|  /\____ /____  > |__| |__|____/____/\___  >
**         \/          \/      \/    \/                         \/
**  Copyright (C) 2000,2005 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#ifndef HEADER_RANDOM_HXX
#define HEADER_RANDOM_HXX

/** */
class Random
{
private:
  /* Period parameters */
  static const unsigned long N = 624;
  static const unsigned long M = 397;
  static const unsigned long MATRIX_A   = 0x9908b0dfUL;   /* constant vector a */
  static const unsigned long UPPER_MASK = 0x80000000UL; /* most significant w-r bits */
  static const unsigned long LOWER_MASK = 0x7fffffffUL; /* least significant r bits */

  unsigned long mt[N]; /* the array for the state vector  */
  unsigned long mti;

public:
  Random(unsigned long seed = 5489UL);

  /** generates a random number on [0,0xffffffff]-interval */
  unsigned long rand();

  long rand(long range);
  long rand(int start, int end);

  /** Returns float random number between [start, end] */
  double drand();

  double drand(double range);

  /** Returns a random number between \a start and \a end */
  double drand(double start, double end);

  /** Returns either 1 or -1 */
  int sign();
private:
  Random (const Random&);
  Random& operator= (const Random&);
};

extern Random rnd;

#endif

/* EOF */
