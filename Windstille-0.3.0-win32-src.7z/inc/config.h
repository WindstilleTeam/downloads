#define PACKAGE_VERSION 0.3
#define PACKAGE_NAME "Windstille"